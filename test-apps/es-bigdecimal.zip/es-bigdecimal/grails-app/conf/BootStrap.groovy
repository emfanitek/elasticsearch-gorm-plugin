import es.bigdecimal.Author

import java.math.MathContext

class BootStrap {

    def init = { servletContext ->
        def iainBanks = new Author(age: new BigDecimal(45.3,MathContext.UNLIMITED))
        iainBanks.save(failOnError: true)
    }
    def destroy = {
    }
}
