package es.bigdecimal

class Author {
    BigDecimal age
    static searchable = true
    static constraints = {
    }
}
